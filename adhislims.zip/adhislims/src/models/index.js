const Quotes = require('./Quotes')
const Authors = require('./Authors')
const Tags = require('./Tags')

module.exports = { Quotes, Authors, Tags }
